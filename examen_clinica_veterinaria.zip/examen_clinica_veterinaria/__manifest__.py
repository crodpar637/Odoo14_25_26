# -*- coding: utf-8 -*-
# Esta línea define la codificación de caracteres del archivo para que Odoo admita tildes y eñes.

{
    # El nombre técnico del módulo que aparecerá en el listado de aplicaciones de Odoo.
    'name': "Clinica veterinaria",

    # Un subtítulo corto que describe la función principal del módulo de un vistazo.
    'summary': "Gestión de veterinario",

    # Una descripción detallada del propósito del módulo y lo que el usuario encontrará en él.
    'description': "Examen Odoo - Gestión modular de usuarios y veterinarios.",

    # Identificación del desarrollador del módulo (en este caso, tú).
    'author': "Fernando",

    # Clasificación de Odoo para organizar el módulo en la tienda de aplicaciones.
    'category': 'Tools',

    # Número de versión del módulo, útil para controlar actualizaciones y migraciones.
    'version': '1.0',

    # Lista de otros módulos de Odoo necesarios para que este funcione (base contiene los modelos esenciales).
    'depends': ['base'],

    # Lista de todos los archivos XML y CSV que Odoo debe leer para cargar la interfaz y permisos.
    'data': [
        # Carga los permisos de acceso para que los modelos sean visibles para los usuarios.
        'security/ir.model.access.csv',
        
        # Define el menú raíz (el icono principal) para organizar los submenús.
        'views/menus.xml', 
        
        # Carga las vistas (formularios, listas, kanban) específicas del modelo de usuarios.
        'views/appointment_views.xml', 
        
        # Carga las vistas y calendarios específicos del modelo de citas.
        'views/veterinaran_views_views.xml',
    ],

    # Indica si el módulo se considera una aplicación completa (aparecerá en el filtro 'Apps' de Odoo).
    'application': True,
}