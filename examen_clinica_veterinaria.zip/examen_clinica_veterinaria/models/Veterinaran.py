# -*- coding: utf-8 -*-

from odoo import models, fields, api

from odoo.exceptions import ValidationError


class Veterinaran(models.Model):
   
    _name = 'examen_clinica_veterinaria.Veterinaran'
    
    _description = 'veterinario'
    
    _rec_name = 'location'

    name = fields.Char(string="Nombre", required=True) 
    email = fields.Char(string="Email", required=True)
    phone = fields.Char(string="Telefono")
    license_number = fields.Char(string="Licencia", required=True)
    photo = field_name =(string='foto')
    

    speciality = fields.Selection([
        ('traumatologia', 'Traumatologia'),
        ('general', 'General'),
        ('cirugia', 'Cirugia'),
        ('demartologia', 'Demartologia')
    ], string="Estado", default='General',required=True)

    status = fields.Selection([
        ('active', 'Activo'),
        ('vacaciones', 'Vacaciones'),
        ('baja', 'Baja')
    ], string="Estado", required=True)
    

    _sql_constraints = [
        ('license_number_unique', 'unique(license_number)', 'La license_number del usuario debe ser único.')
    ]

    _sql_constraints = [
        ('email_unique', 'unique(email)', 'El email del usuario debe ser único.')
    ]

    num_appointments = fields.Integer(string="Nº Citas", compute='_compute_num_appointments')

    
    appointments_ids = fields.One2many('examen_clinica_veterinaria.appointment', 'user_from_id', string="Citas Solicitadas")
    

    @api.depends('appointments_ids')
    def _compute_num_appointments(self):
        for record in self:
            record.num_appointments = len(record.appointments_ids)

    
    def action_activate_profile(self):
        self.status = 'active'

    def action_take_break(self):
        self.status = 'vacaciones'

    def action_ban_user(self):
        self.status = 'baja'