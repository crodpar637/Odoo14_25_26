# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Appointment(models.Model):
   
    _name = 'examen_clinica_veterinaria.Appointment'
    _description = 'usuario'
    _rec_name = 'name'

   
    name = fields.Datetime(string="Fecha y Hora", required=True)
    pet_name = fields.Char(string="pet", required=True)
    owner_name = fields.Char(string="owner",required=True)
    owner_phone = fields.Char(string="Telefono",required=True)
    reason = fields.Text(string="Notas")

    veterinaran_id = fields.Many2one('examen_clinica_veterinaria.Veterinaran', string="Usuario Destino", required=True)
    
    # Campo de selección con opciones fijas.
    gender = fields.Selection([
        ('male', 'Masculino'),
        ('female', 'Femenino'),
        ('other', 'Otro')
    ], string="Género")
    
    # Campo para almacenar archivos binarios (imágenes en este caso).
    photo = fields.Binary(string="Fotografía")
    # Campo de texto multilínea sin formato.
    biography = fields.Text(string="Biografía")
    
    # Campo de estado: 'readonly=True' impide que el usuario lo cambie a mano; se cambia vía botones.
    status = fields.Selection([
        ('active', 'Activo'),
        ('on_break', 'Tomar un descanso'),
        ('banned', 'Bloqueado')
    ], string="Estado", default='active', readonly=True)

    # RELACIONES: One2many (La contraparte de los Many2one definidos en match.appointment).
    # 'match_ids' obtiene las citas donde este usuario es el solicitante.
    match_ids = fields.One2many('match.appointment', 'user_from_id', string="Citas Solicitadas")
    # 'received_match_ids' obtiene las citas donde este usuario es el destino.
    received_match_ids = fields.One2many('match.appointment', 'user_to_id', string="Citas Recibidas")

    # CAMPO COMPUTADO: No se guarda en la BD (por defecto), se calcula en tiempo real.
    num_appointments = fields.Integer(string="Nº Citas", compute='_compute_num_appointments')

    # RESTRICCIONES SQL: Se aplican directamente a nivel de base de datos (más rápidas).
    _sql_constraints = [
        ('email_unique', 'unique(email)', 'El email del usuario debe ser único.')
    ]

    # MÉTODO COMPUTE: Suma el total de citas solicitadas y recibidas.
    @api.depends('match_ids', 'received_match_ids')
    def _compute_num_appointments(self):
        for record in self:
            # len() cuenta los elementos de las listas de relaciones One2many.
            record.num_appointments = len(record.match_ids) + len(record.received_match_ids)

    # ACCIONES DE BOTONES: Cambian el valor del campo 'status'.
    def action_activate_profile(self):
        self.status = 'active'

    def action_take_break(self):
        self.status = 'on_break'

    def action_ban_user(self):
        self.status = 'banned'

    # ACCIÓN ESPECIAL: Buscar y eliminar registros relacionados.
    def action_delete_pending_appointments(self):
        for record in self:
            # .search() busca en el modelo de citas. El '|' es el operador OR de Odoo.
            appointments_to_delete = self.env['match.appointment'].search([
                ('status', '=', 'pending'), # Condición 1: Que estén pendientes.
                '|',                        # Operador OR para las siguientes dos condiciones.
                ('user_from_id', '=', record.id),
                ('user_to_id', '=', record.id)
            ])
            # .unlink() borra físicamente los registros encontrados de la base de datos.
            appointments_to_delete.unlink()